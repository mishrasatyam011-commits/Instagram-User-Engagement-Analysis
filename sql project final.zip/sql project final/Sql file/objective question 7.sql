--- objective question 7 (Get the list of users who have never liked any post (users and likes tables)

SELECT 
  u.id,
  u.username
FROM 
  users u
WHERE 
  u.id NOT IN (SELECT user_id FROM likes);
