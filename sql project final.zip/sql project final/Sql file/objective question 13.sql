--- objective questive 13 (Retrieve the users who have started following someone after being followed by that person)

SELECT 
  f1.follower_id AS user_id,
  f1.followee_id AS followed_back_to
FROM  follows f1
JOIN follows f2 
    ON f1.follower_id = f2.followee_id 
   AND f1.followee_id = f2.follower_id
WHERE 
  f1.follow_create > f2.follow_create;

