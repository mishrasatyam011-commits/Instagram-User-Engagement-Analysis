--- subjective question 4(Are there any patterns or trends in user engagement based on demographics (age, location, gender) or posting times? How can these insights inform targeted marketing campaigns?)

SELECT 
    HOUR(p.created_dat) AS hour_of_day,
    DAYOFWEEK(p.created_dat) AS day_of_week,
    COUNT(DISTINCT l.user_id) AS unique_likes,
    COUNT(DISTINCT p.id) AS photos_uploaded,
    COUNT(DISTINCT c.id) AS comments_made
FROM photos p
LEFT JOIN comments c ON p.id = c.photo_id
LEFT JOIN likes l ON p.id = l.photo_id
GROUP BY hour_of_day, day_of_week
ORDER BY hour_of_day, day_of_week;
