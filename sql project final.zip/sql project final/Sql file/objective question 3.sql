--- objective question 3(Calculate the average number of tags per post (photo_tags and photos tables)).

with CTE as (
                          select   p.id, 
                          count(pt.tag_id) AS tag_count
    from photos p
    left join  photo_tags pt ON p.id = pt.photo_id
    group by  p.id
   )
      Select  
      avg (tag_count) AS average_tags_per_post
      From CTE;
