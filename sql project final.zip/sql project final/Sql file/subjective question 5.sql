--- subjective question 5(Based on follower counts and engagement rates, which users would be ideal candidates for influencer marketing campaigns? How would you approach and collaborate with these influencers)

SELECT 
    u.id AS user_id,
    u.username,
    COUNT(DISTINCT p.id) AS photos_uploaded,
    COUNT(DISTINCT l.user_id) AS total_likes,
    COUNT(DISTINCT c.id) AS total_comments,
    (SELECT COUNT(DISTINCT f.follower_id)
     FROM follows f
     WHERE f.followee_id = u.id) AS followers_count,
    (COUNT(DISTINCT l.user_id) + COUNT(DISTINCT c.id)) / 
    (SELECT COUNT(DISTINCT f.follower_id)
     FROM follows f
     WHERE f.followee_id = u.id) AS engagement_rate
FROM users u
LEFT JOIN photos p ON u.id = p.user_id
LEFT JOIN likes l ON p.id = l.photo_id
LEFT JOIN comments c ON p.id = c.photo_id
GROUP BY u.id
ORDER BY engagement_rate DESC;
