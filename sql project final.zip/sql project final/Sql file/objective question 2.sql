---- objective question 2 (What is the distribution of user activity levels (e.g., number of posts, likes, comments) across the user base)

with user_activity as (select u.id,
							count(distinct i.photo_id) as num_like,
							count(distinct c.id) as num_comment,
							count(distinct p.id) as num_post
          from users u 
          left join likes i on u.id = i.user_id
          left join comments c on u.id = c.user_id
          left join photos p on u.id = p.user_id
          group by u.id)
          select   num_like,
                        num_comment,
                        num_post,
                        count(*) as num_user
          from user_activity
          group by num_like,num_comment,num_post
          order by num_user desc;
