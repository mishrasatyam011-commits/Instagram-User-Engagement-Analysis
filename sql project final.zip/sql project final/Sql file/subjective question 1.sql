--- subjective question 1 (Based on user engagement and activity levels, which users would you consider the most loyal or valuable? How would you reward or incentivize these users?)

SELECT 
    u.id AS user_id, 
    u.username, 
    COUNT(DISTINCT p.id) AS photo_count, 
    COUNT(DISTINCT c.id) AS comment_count,
    COUNT(DISTINCT l.photo_id) AS like_count,
    (SELECT COUNT(*) FROM follows f WHERE f.follower_id = u.id) AS followers_count, 
    (SELECT COUNT(*) FROM follows f WHERE f.followee_id = u.id) AS following_count  
FROM users u
LEFT JOIN  photos p ON u.id = p.user_id  
LEFT JOIN comments c ON p.id = c.photo_id 
LEFT JOIN  likes l ON p.id = l.photo_id 
GROUP BY u.id
ORDER BY 
    photo_count DESC, comment_count DESC, like_count DESC, followers_count DESC
